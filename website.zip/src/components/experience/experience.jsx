import React from 'react'
import "./experience.css"
import { BsPatchCheckFill} from 'react-icons/bs'
export const Experience = () => {
  return (
    <section id = "experience">
      <h5> Skills</h5>
      <h2> My Experience</h2>


      <div className='container experience__container'>
        <div className='experience__programming'>
          <h3> Programming</h3>
          <div className='experience__content'>
            <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>Python</h4>
                <small className='text-light'> Advanced</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>JavaScript</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>R-Programming</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>HTML and CSS</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>Linux</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
            </div>
            </div>
            {/* END OF FIRST BOX */ }

          <div className = "experience__mlai">
          <h3> Data Science</h3>
          <div className='experience__content'>
          <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>SQL</h4>
                <small className='text-light'> Advanced</small>
                </div>

              </article>
            <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>Supervised Learning</h4>
                <small className='text-light'> Advanced</small>
                </div>

              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>Unsupervised Learning</h4>
                <small className='text-light'> Advanced</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>Deep Learning</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
              <article className='experience__details'>
                <BsPatchCheckFill className = "experience__details-icon"/>
                <div>
                <h4>A/B Testing</h4>
                <small className='text-light'> Intermediate</small>
                </div>
              </article>
            
            </div>
          </div>
          </div>
    </section>
  )
}
