from math import radians
from operator import sub
from selenium import webdriver
import json
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
options = Options()
options.add_argument("--incognito")


class LinkedInBot:

    def __init__(self, data):
        """Parameters Initalization"""
        self.email = data["email"]
        self.password = data["password"]
        self.keyword = data["keyword"]
        self.contract = data["contract"]
        self.driver = webdriver.Chrome(data['driver_path_c'], options=options)
        self.linkedin_link = data['login_link']
        self.filter_data = data['all_filters'][0]
        self.country = data['country']
        self.phone = data['phone_number']
        self.resume_path = data['resume_path']
        self.years_exp = data['number_of_years_exp']

    def login(self):
        """This function logs in to LinkedIn using Email and Passoword"""
        # opens the browser with link
        self.driver.get(self.linkedin_link)
        self.driver.maximize_window()

        login_email = self.driver.find_element(By.NAME, "session_key")
        login_email.clear()
        login_email.send_keys(self.email)

        login_password = self.driver.find_element(By.ID, "password")
        login_password.clear()
        login_password.send_keys(self.password)
        login_password.send_keys(Keys.RETURN)
        time.sleep(3)

    def JobSearch(self):
        """This locates the search menu, and finds jobs"""
        try:
            element = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.LINK_TEXT, 'Jobs')))
            jobs_link = self.driver.find_element(By.LINK_TEXT, 'Jobs')
            jobs_link.click()
        except:
            self.driver.quit()
        finally:
            time.sleep(1)

        # move to the designated search bar page after arriving in the job page
        self.driver.execute_script("window.scrollTo(0, 550)")
        time.sleep(2)
        show_all = self.driver.find_elements(
            By.XPATH, '/html/body/div[5]/div[3]/div/div[3]/div/div/main/div[2]/div[1]/div[1]/div/section/div[2]/a')
        show_all[0].click()

        # click the search button to reveal all the criterias
        time.sleep(4)
        search_button = self.driver.find_elements(
            By.XPATH, "/html/body/div[5]/header/div/div/div/div[2]/button[1]")
        search_button[0].click()

        # getting the main of the search page
        jobs_search_main_page = self.driver.find_element(
            By.CLASS_NAME, "application-outlet")

        # waiting for the filter bar to appear then finds the filter criteria and clicks on the easy apply button
        try:
            element = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
                (By.XPATH, '//*[@id="search-reusables__filters-bar"]/div/div')))
            filters_button = self.driver.find_element(
                By.XPATH, '//*[@id="search-reusables__filters-bar"]/ul/li[8]/div')
            filters_button.click()
        except:
            self.driver.quit()
        finally:
            time.sleep(3)

        # # minimizes the messaging bar
        # self.driver.find_element(
        #     By.XPATH, '/html/body/div[5]/aside/div[1]/header/div[3]/button[2]').click()
        # time.sleep(3)

    def filterApply(self):
        """Applies the Criteria in Country and Job Field and then applies to the job by easyapply"""

        # Puts in the filter for Experience Level and presses the experience level button
        try:
            WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(
                (By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[5]/div/span/button")))
            exp_level = self.driver.find_element(
                By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[5]/div/span/button")
            exp_level.click()
        except Exception as e:
            time.sleep(5)
            self.driver.quit()
        finally:
            time.sleep(3)

            # puts in teh entry level button then hits show all results
        try:
            WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(
                (By.XPATH, "//label[starts-with(@for, 'experience-2')]")))
            entry_level = self.driver.find_element(
                By.XPATH, "//label[starts-with(@for, 'experience-2')]")
            entry_level.click()
            show_results_button = self.driver.find_element(
                By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[5]/div/div/div/div[1]/div/form/fieldset/div[2]/button[2]/span")
            show_results_button.click()
        except Exception as e:
            time.sleep(5)
            self.driver.quit()
        finally:
            time.sleep(3)

        # Job Type click on button
        try:
            WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(
                (By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[7]/div/span/button")))
            job_type = self.driver.find_element(
                By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[7]/div/span/button")
            job_type.click()
        except Exception as e:
            time.sleep(5)
            self.driver.quit()
        finally:
            time.sleep(3)

            # puts in Full-time position button then hits show all results
        try:
            WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(
                (By.XPATH, "//label[starts-with(@for, 'jobType-F')]")))
            exp_level = self.driver.find_element(
                By.XPATH, "//label[starts-with(@for, 'jobType-F')]")
            exp_level.click()
            show_results_button = self.driver.find_element(
                By.XPATH, "/html/body/div[5]/div[3]/div[4]/section/div/section/div/div/div/ul/li[7]/div/div/div/div[1]/div/form/fieldset/div[2]/button[2]/span")
            show_results_button.click()
        except Exception as e:
            time.sleep(5)
            self.driver.quit()
        finally:
            time.sleep(3)

        # introduce job keyword and location and enter
        try:
            WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(
                (By.XPATH, '//input[starts-with(@id,"jobs-search-box-keyword-id")]')))
            job_keyfield = self.driver.find_element(
                By.XPATH, '//input[starts-with(@id,"jobs-search-box-keyword-id")]')
            job_keyfield.clear()
            job_keyfield.send_keys(self.keyword)
        except Exception as e:
            time.sleep(5)
            print(e)
            self.driver.quit()
        finally:
            time.sleep(3)
        # Puts in an input for the Country KeyWord and click the search button to reveal all the criterias
        try:
            WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(
                (By.XPATH, '//input[starts-with(@id,"jobs-search-box-location-id")]')))
            country_keyfield = self.driver.find_element(
                By.XPATH, '//input[starts-with(@id,"jobs-search-box-location-id")]')
            country_keyfield.clear()
            country_keyfield.send_keys(self.country)
            time.sleep(4)
            search_button = self.driver.find_elements(
                By.XPATH, "/html/body/div[5]/header/div/div/div/div[2]/button[1]")
            search_button[0].click()
        except Exception as e:
            print(e)
            self.driver.quit()
        finally:
            time.sleep(3)

    def answer_questions(self):
        # Work Authorization
        heading = self.driver.find_element(
            By.XPATH, '//h3[starts-with(@class,"t-16")]')
        sub_heading = './/span[starts-with(@class,"t-14")]'
        grouped_up_div = self.driver.find_elements(
            By.XPATH, '//div[starts-with(@class,"jobs-easy-apply-form")]')  # total path
        # relative pathing
        text_field = './/input[starts-with(@id,"urn:li:fs_easyApplyFormElement:")]'
        radio_button = './html/body/div[3]/div/div/div[2]/div/div[2]/form/div/div/div[2]/fieldset/div/div[1]/label'
        for div in grouped_up_div:  # for each div
            if (heading).text == "Work authorization":  # if title is Work Authorization
                # they have seperate XPAths for some reason
                if (div.find_element(By.XPATH, sub_heading)).text == "Are you legally authorized to work in the United States?":
                    div.find_element(By.XPATH, radio_button).click()
                else:
                    div.find_element(
                        By.XPATH, '/html/body/div[3]/div/div/div[2]/div/div[2]/form/div/div/div[1]/fieldset/div/div[1]/label').click()
            elif (heading).text == "Additional Questions":
                # Loop through each div with a question #if Title is additional Questions
                try:
                    if (div.find_element(By.XPATH, text_field)):  # checking if  div is text field
                        # then clears div
                        div.find_element(By.XPATH, text_field).clear()
                        div.find_element(By.XPATH, text_field).send_keys(
                            self.years_exp)  # and puts in the years value
                    else:
                        pass
                except:
                    time.sleep(4)
                    if (div.find_element(By.XPATH, radio_button)):
                        div.find_element(By.XPATH, radio_button).click()
                    else:
                        pass
        return len(grouped_up_div)

# starting to do easy apply figure out how to apply for all jobs also might need to open from incognito mode from now on

    def easyApply(self):
        """_summary_
        Applies to each of the 
        """
        time.sleep(3)
        # finds the Easy apply button that appears first on page and clicks it
        self.driver.find_element(
            By.XPATH, '/html/body/div[5]/div[3]/div[4]/div/div/main/div/section[2]/div/div[2]/div[1]/div/div[1]/div/div[1]/div[1]/div[3]/div/div/div/button'
        ).click()
        time.sleep(3)

        email = self.driver.find_element(
            By.XPATH, '//div[starts-with(@class,"fb-dropdown")]')
        email.click()

        phone_nu = self.driver.find_element(
            By.XPATH, '//input[starts-with(@id,"urn:li:fs_easyApplyFormElement:")]')
        phone_nu.send_keys(self.phone)

        # click the next button
        next = self.driver.find_element(
            By.XPATH, '//button[starts-with(@aria-label,"Continue to next step")]'
        )
        next.click()
        time.sleep(3)

        # upload resume
        try:
            WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(
                (By.XPATH, "//input[@type='file']")))
            field = self.driver.find_element(
                By.XPATH, "//input[@type='file']")
            field.send_keys(self.resume_path)
        except Exception as e:
            print(e)
            self.driver.quit()
        finally:
            time.sleep(3)

        next = self.driver.find_element(
            By.XPATH, '//button[starts-with(@aria-label,"Continue to next step")]')
        next.click()  # click the next button
        while True:
            try:
                self.answer_questions()
                next = self.driver.find_element(
                    By.XPATH, '//button[starts-with(@aria-label,"Continue to next step")]')
                next.click()  # click the next button
                time.sleep(3)
                # calls the answer questions function
            except:
                self.answer_questions()
                review = self.driver.find_element(
                    By.XPATH, '//button[starts-with(@aria-label,"Review your application")]')
                review.click()
                time.sleep(3)
                follow_check = self.driver.find_element(
                    By.XPATH, "/html/body/div[3]/div/div/div[2]/div/div[2]/div/footer/div[1]/label"
                )
                follow_check.click()
                time.sleep(1)
                submit_application = self.driver.find_element(
                    By.XPATH, '//button[starts-with(@aria-label,"Continue to next step")]')
                submit_application.click()  # Finally Sumbitting Application :D
                time.sleep(3)
                break

        # def logout(self):
        #     self.driver.quit()


if __name__ == '__main__':

    with open('config.json') as config_file:
        data = json.load(config_file)

    bot = LinkedInBot(data)
    bot.login()
    bot.JobSearch()
    bot.filterApply()
    a = bot.easyApply()
    print(a)
    # "email":"abhitestemail246@gmail.com",
    # "password": "qweasdzxc123",
    #     "email":"aavamadev@gmail.com",
    # "password": "Bestdraven!123",
