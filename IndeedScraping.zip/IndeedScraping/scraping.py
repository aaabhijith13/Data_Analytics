import pandas as pd
from bs4 import BeautifulSoup
from requests import get
import json
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class IndeedScraping():

    """_summary_
    Takes in data to output a csv file scrapped from Indeed based on keywords
    """

    def __init__(self, data):
        """_initalization_
        Initalization of variables required
        Args:
            url: Indeed Url
            job: Job keyword from config
            location: Job Location from config
        """
        self.url = data["url"]
        self.job = data["job_keyword"]
        self.location = data["location"]
        self.path = data['driver_path']
        self.driver = webdriver.Chrome(self.path)
        self.init_dict = {
            "JobTitle": "",
            "Company": "",
            "Location": "",
            "ContractType": "",
            "ApplicationType": "",
            "Description": "",
            "Salary": "",
            "Link": ""

        }
        self.final_list = []

    def scraping(self):
        """Begins Scraping from the website and convert it into a dict and finally a list
        """
        formatted_url = self.url.format(self.job, self.location)
        self.driver.maximize_window()
        self.driver.get(formatted_url)

        while True:

            all_cards = self.driver.find_elements(
                By.XPATH, '//div[starts-with(@class, "job_seen_beacon")]')

            # iterating through all cards
            for iteration, card in enumerate(all_cards):
                # finds the card element and clicks on it to reveal the side card from where info is then collected
                card.click()
                # time.sleep(3)

            #     ### Job Title #####
            #     try:
            #         WebDriverWait(self.driver, 5).until(  # waiting for the presence of the job title
            #             EC.presence_of_element_located((
            #                 By.XPATH, "//h1[starts-with(@class, 'icl-u-xs-mb--xs')]"
            #             )))
            #         job_title = self.driver.find_element(
            #             # retreiving the text
            #             By.XPATH, "//h1[starts-with(@class, 'icl-u-xs-mb--xs')]"
            #         ).text
            #     except:
            #         job_title = 'N/A'  # if not found returns N/A

            #     ### Company #####

            #     try:
            #         WebDriverWait(self.driver, 5).until(  # waiting for the presence of company element
            #             EC.presence_of_element_located((
            #                 By.XPATH, '//*[@id="jobsearch-ViewjobPaneWrapper"]/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[1]/div[2]/div/div/div/div[1]/div[2]/div/a'
            #             )))
            #         company = self.driver.find_element(
            #             By.XPATH, '//*[@id="jobsearch-ViewjobPaneWrapper"]/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[1]/div[2]/div/div/div/div[1]/div[2]/div/a'
            #         ).text  # retreviing the text
            #     except:
            #         try:
            #             WebDriverWait(self.driver, 5).until(  # since there are variations in company XPATH's looking for all posibilities
            #                 EC.presence_of_element_located((
            #                     By.XPATH, '//*[@id="jobsearch-ViewjobPaneWrapper"]/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[2]/div/a')))
            #             company = self.driver.find_element(
            #                 By.XPATH, '//*[@id="jobsearch-ViewjobPaneWrapper"]/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[2]/div/a'
            #             ).text
            #         except:
            #             company = 'N/A'  # if nothing found returns none

            #     ### Location #####

            #     try:
            #         WebDriverWait(self.driver, 5).until(  # looks for location and get the text
            #             EC.presence_of_element_located((
            #                 By.XPATH, "//*[@id='jobsearch-ViewjobPaneWrapper']/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div")))
            #         location = self.driver.find_element(
            #             By.XPATH, "//*[@id='jobsearch-ViewjobPaneWrapper']/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div"
            #         ).text
            #     except:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.XPATH, "/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[1]/div[2]/div/div/div/div[2]/div")))
            #         location = self.driver.find_element(
            #             By.XPATH, "/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[1]/div[2]/div/div/div/div[2]/div"
            #         ).text

            #     if (location == 'Remote▒Remote'):
            #         location = 'Remote'

            # ### Contract #####

            #     try:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.XPATH, '/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]')))
            #         contract = self.driver.find_element(
            #             By.XPATH, '/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]'
            #         ).text
            #     except:
            #         try:
            #             WebDriverWait(self.driver, 5).until(
            #                 EC.presence_of_element_located((
            #                     By.XPATH, '//*[@id="jobDetailsSection"]/div[3]/div[2]')))
            #             contract = self.driver.find_element(
            #                 By.XPATH, '//*[@id="jobDetailsSection"]/div[3]/div[2]'
            #             ).text
            #         except:
            #             contract = 'N/A'

            # ### ApplicationType####
            #     try:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.XPATH, './/tr[starts-with(@class, "jobCardShelf")]')))
            #         applicationType = self.driver.find_element(
            #             By.XPATH, './/tr[starts-with(@class, "jobCardShelf")]'
            #         ).text
            #         applicationType = "Easy Apply"
            #     except:
            #         applicationType = "Company Site"
            #         # taking all the variables into a dictionary

            # ### Description ####
            #     try:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.ID, 'jobDescriptionText')))
            #         description = self.driver.find_element(
            #             By.ID, 'jobDescriptionText'
            #         ).text
            #     except:
            #         description = "N/A"

            # ### Salary ####
            #     try:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.CLASS_NAME, 'attribute_snippet')))
            #         salary = self.driver.find_element(
            #             By.CLASS_NAME, 'jattribute_snippet'
            #         ).text
            #     except:
            #         salary = "N/A"

            # ### Link ####
            #     try:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.XPATH, '/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[4]/div/div[3]/div/div/div[2]/a')))
            #         link = self.driver.find_element(
            #             By.XPATH, '/html/body/main/div/div[1]/div/div/div[5]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[1]/div[1]/div[4]/div/div[3]/div/div/div[2]/a'
            #         ).get_attribute('href')
            #     except:
            #         WebDriverWait(self.driver, 5).until(
            #             EC.presence_of_element_located((
            #                 By.XPATH, '/ html/body/main/div/div[1]/div/div/div[5]/div[1]/div[5]/div/ul/li[1]/div/div[1]/div/div[1]/div/table[1]/tbody/tr/td/div[1]/h2/a')))
            #         link = self.driver.find_element(
            #             By.XPATH, '/ html/body/main/div/div[1]/div/div/div[5]/div[1]/div[5]/div/ul/li[1]/div/div[1]/div/div[1]/div/table[1]/tbody/tr/td/div[1]/h2/a'
            #         ).get_attribute('href')

            #         # taking all the variables into a dictionary
            #     # stripping the string and removing - Job Type from the string
            #     self.init_dict['JobTitle'] = job_title.strip()[:-11]
            #     self.init_dict['Company'] = company
            #     self.init_dict['Location'] = location
            #     self.init_dict['ContractType'] = contract
            #     self.init_dict['ApplicationType'] = applicationType
            #     self.init_dict['Description'] = description
            #     self.init_dict['Salary'] = salary
            #     self.init_dict['Link'] = link

            #     # finally appending a copy of each of the dictionaries to the final list
            #     self.final_list.append(self.init_dict.copy())
                print("Successfully, Scraped Job number: {}".format(iteration))

                # clicking on the next page
            try:
                WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located((
                        By.XPATH, "//a[starts-with(@aria-label, 'Next')]"
                    )))
                next_page = self.driver.find_element(
                    By.XPATH, "//a[starts-with(@aria-label, 'Next')]"
                )
                next_page.click()
            except AttributeError:
                break

    def logout(self):
        """Logs out after the whole process
        """
        time.sleep(3)
        self.driver.quit()
        time.sleep(3)
        print("Program has shut down, a new csv file has been returned")

    def format(self, scrap_data):
        """Converts the scrapped data into a readable csv table format 
        """
        print(scrap_data)
        df = pd.DataFrame(scrap_data)
        return df


if __name__ == "__main__":
    with open('config.json') as config_file:
        scrap = IndeedScraping(json.load(config_file))
        scraped_data = scrap.scraping()
        print(scraped_data)
        format_data = scrap.format(scraped_data)
        print(format_data)
        #logout = scrap.logout()
        # logout
